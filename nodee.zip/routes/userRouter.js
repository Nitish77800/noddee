
const userRouter = require("express").Router();
const user = require('../controllers/user');
userRouter.post('/signup',user.signup)


module.exports = userRouter;