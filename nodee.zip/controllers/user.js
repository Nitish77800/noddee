const userModel = require('../model/user');
const common = require('../helper/common');
const bcrypt = require('bcryptjs');

module.exports ={

    // api development

    // signup,login,otpverify,forgotpassword,resetpassword,resend otp,getProfile

    signup:(req,res)=>{
        try {
            userModel.findOne({email:req.body.email},(err,result)=>{
                if(err){
                    return res.status(500).send({responseMessage:"Internal server error",responseCode:501,error:err})

                }
                else if(result){
                    return res.status(500).send({responseMessage:"email already exists",responseCode:401,error:[]})
                }
                else { 
                /* genrate OTP...!! */
                    let newotp = Math.floor(100000 + Math.random() * 900000).toString();
                    req.body.otp = newotp;
                    console.log(req.body);
                    
                /* hashing the password..!!  */
                    let password = bcrypt.hashSync(req.body.password);
                    req.body.password = password;
                    console.log(req.body);

                    userModel(req.body).save((err1,res1)=>{
                        if(err1){
                            return res.status(500).send({responseMessage:"Internal server error",responseCode:501,error:err1})
        
                        }
                        else{
                            return res.status(200).send({responseMessage:"Signup success",responseCode:200,result:res1})
                        }
                    })
                }
            })
        } catch (error) {
            console.log(error);
            return res.status(501).send({responseMessage:"Something went wrong",responseCode:501,error:error})
        }
    }

}